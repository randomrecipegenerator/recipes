import os
import json
import random
from datetime import datetime
import markdown
import re

class ArticleWriter:
    def __init__(self):
        self.intro_templates = [
            "In today's fast-paced world, {keyword} has become increasingly important for home cooks and food enthusiasts alike. Whether you're looking to save time, reduce waste, or simply expand your culinary horizons, understanding {keyword} can transform your cooking experience.",
            "Have you ever wondered about {keyword}? This increasingly popular approach to cooking has gained traction among both professional chefs and home cooks. In this comprehensive guide, we'll explore everything you need to know about {keyword} and how it can revolutionize your kitchen experience.",
            "The world of cooking is constantly evolving, and {keyword} represents one of the most exciting developments in recent years. If you're looking to enhance your culinary skills and discover new possibilities in the kitchen, {keyword} offers a wealth of opportunities worth exploring.",
            "When it comes to modern cooking solutions, {keyword} stands out as a game-changer for many food enthusiasts. This innovative approach has transformed how people think about meal preparation and recipe discovery, offering unprecedented flexibility and creativity in the kitchen."
        ]
        
        self.conclusion_templates = [
            "As we've explored throughout this article, {keyword} offers tremendous value for anyone looking to enhance their cooking experience. By incorporating these ideas into your culinary routine, you'll discover new possibilities and enjoy more efficient, creative meal preparation. Why not give it a try today?",
            "In conclusion, {keyword} represents an exciting frontier in modern cooking. Whether you're an experienced chef or a casual home cook, the techniques and approaches we've discussed can help you save time, reduce waste, and discover delicious new meal ideas. Start your journey with {keyword} today and transform your relationship with food.",
            "The world of {keyword} continues to evolve, offering ever more sophisticated and user-friendly solutions for cooks of all skill levels. By staying informed about these developments and experimenting with the approaches outlined in this article, you'll be well-positioned to enjoy the many benefits that {keyword} has to offer.",
            "As we've seen, {keyword} has the potential to revolutionize your approach to cooking and meal planning. By embracing these innovative techniques and tools, you'll not only save time and reduce stress in the kitchen but also discover exciting new culinary possibilities. The future of cooking is here—are you ready to be part of it?"
        ]
        
        self.section_templates = {
            "What is {keyword}?": [
                "{keyword} refers to a modern approach to cooking that leverages technology and smart algorithms to help home cooks create delicious meals based on available ingredients. Unlike traditional recipe searching, which requires you to find recipes then shop for ingredients, {keyword} reverses this process, starting with what you already have.",
                "At its core, {keyword} is a culinary innovation that bridges the gap between available ingredients and potential recipes. It uses sophisticated algorithms to analyze ingredient combinations, cooking techniques, and flavor profiles to suggest recipes that maximize the use of items you already have on hand.",
                "{keyword} represents a paradigm shift in how we approach cooking at home. Rather than following rigid recipes that demand specific ingredients, this approach offers flexibility by suggesting meals based on what's already in your kitchen, reducing waste and saving time on shopping trips."
            ],
            
            "Benefits of {keyword}": [
                "The advantages of {keyword} extend far beyond simple convenience. By starting with ingredients you already have, you'll reduce food waste significantly, saving both money and environmental resources. Additionally, this approach encourages culinary creativity, helping you break out of cooking ruts and discover new flavor combinations.",
                "Embracing {keyword} offers multiple benefits for home cooks. First, it reduces food waste by utilizing ingredients before they spoil. Second, it saves money by maximizing existing pantry items. Third, it saves time by eliminating unnecessary shopping trips. Finally, it expands your culinary horizons by suggesting recipes you might never have considered.",
                "Why has {keyword} gained such popularity? The benefits are compelling: reduced food waste, lower grocery bills, fewer shopping trips, and expanded culinary creativity. For busy households, these advantages translate to less stress around meal planning and more enjoyment in the cooking process."
            ],
            
            "How to Get Started with {keyword}": [
                "Beginning your journey with {keyword} is straightforward. Start by taking inventory of your pantry, refrigerator, and freezer. Next, choose a reliable {keyword} tool or app that matches your preferences. Enter your available ingredients, specify any dietary restrictions, and let the system generate recipe suggestions. Finally, experiment with the results, adjusting to your taste preferences.",
                "Getting started with {keyword} requires just a few simple steps. First, gather all available ingredients from your kitchen. Second, select a reputable {keyword} platform that suits your needs. Third, input your ingredients and any dietary preferences. Finally, review the suggested recipes and select one that appeals to you. With practice, this process becomes second nature.",
                "To begin using {keyword} effectively, follow these steps: 1) Conduct a thorough inventory of your kitchen ingredients; 2) Choose a {keyword} tool with positive reviews and features that match your needs; 3) Enter your ingredients, being as specific as possible; 4) Specify any dietary restrictions or preferences; 5) Browse the suggested recipes and select one to prepare."
            ],
            
            "Common Mistakes to Avoid": [
                "While {keyword} offers many advantages, there are common pitfalls to avoid. Don't limit yourself to exact ingredient matches—many recipes allow for substitutions. Avoid ignoring suggested cooking techniques, as these can significantly impact the final result. Don't forget to update your ingredient inventory regularly for the most accurate suggestions. Finally, resist the temptation to add too many restrictions, which can severely limit your recipe options.",
                "Even experienced cooks make mistakes when first using {keyword}. The most common errors include: being too rigid about exact ingredient matches, overlooking the importance of proper cooking techniques, failing to update ingredient lists after shopping, and setting too many dietary restrictions simultaneously. By avoiding these mistakes, you'll get much better results from your {keyword} experience.",
                "To maximize your success with {keyword}, be aware of these common mistakes: 1) Expecting perfect ingredient matches rather than embracing substitutions; 2) Ignoring the importance of cooking methods; 3) Working with outdated ingredient inventories; 4) Setting unrealistic expectations for results; and 5) Failing to provide feedback to improve future suggestions."
            ],
            
            "Advanced {keyword} Techniques": [
                "Once you've mastered the basics of {keyword}, you can explore more advanced techniques. Try combining suggestions from multiple sources for more creative options. Experiment with ingredient substitutions to adapt recipes to your preferences. Create custom ingredient categories to streamline the input process. Finally, maintain a feedback loop by rating recipes to improve future suggestions.",
                "Advanced users of {keyword} employ several sophisticated strategies to enhance their experience. These include: creating custom ingredient templates for quick input, developing personal substitution rules for flexibility, maintaining digital pantry inventories that sync with shopping lists, and using historical cooking data to inform future recipe selections.",
                "Taking your {keyword} experience to the next level involves several advanced techniques. Consider implementing a digital inventory system that tracks ingredient expiration dates. Develop personal recipe templates that can be adapted based on available ingredients. Create a substitution database for common ingredients. Finally, integrate meal planning with your {keyword} approach for more cohesive weekly menus."
            ],
            
            "Tools and Resources": [
                "The {keyword} ecosystem offers numerous tools and resources to enhance your cooking experience. Popular applications include SuperCook, Mealime, and Allrecipes Dinner Spinner. For more specialized needs, consider Eat By Date for ingredient freshness information, Substitution charts for ingredient alternatives, and Flavor Bible for understanding complementary flavor profiles.",
                "To maximize your {keyword} success, consider these essential tools and resources: Recipe generator applications (both web and mobile), ingredient substitution guides, flavor pairing databases, seasonal produce calendars, and basic inventory management systems. Together, these resources create a comprehensive support system for your {keyword} journey.",
                "The most successful practitioners of {keyword} utilize a combination of digital tools and traditional resources. Key digital tools include recipe generator apps, inventory management systems, and meal planning software. Valuable traditional resources include substitution guides, flavor pairing references, and technique-focused cookbooks. By leveraging both types of resources, you'll achieve the best possible results."
            ]
        }
        
    def generate_article_from_outline(self, outline):
        """Generate a full article from an outline"""
        article = {
            "title": outline["title"],
            "keyword": outline["keyword"],
            "date": datetime.now().strftime("%Y-%m-%d"),
            "content": ""
        }
        
        # Generate content for each section
        full_content = []
        
        # Add introduction
        intro = random.choice(self.intro_templates).replace("{keyword}", outline["keyword"])
        full_content.append(f"# {outline['title']}\n\n{intro}\n\n")
        
        # Add each section
        for section in outline["sections"][1:-1]:  # Skip intro and conclusion
            full_content.append(f"## {section}\n\n")
            
            # Find matching template or use generic
            template_key = next((k for k in self.section_templates.keys() if k.replace("{keyword}", outline["keyword"]) == section), None)
            
            if template_key and template_key in self.section_templates:
                section_content = random.choice(self.section_templates[template_key]).replace("{keyword}", outline["keyword"])
                full_content.append(f"{section_content}\n\n")
            else:
                # Generate generic content based on section name
                section_content = f"This section explores {section.lower()} in detail, providing valuable insights and practical advice for readers interested in {outline['keyword']}."
                full_content.append(f"{section_content}\n\n")
        
        # Add conclusion
        conclusion = random.choice(self.conclusion_templates).replace("{keyword}", outline["keyword"])
        full_content.append(f"## Conclusion\n\n{conclusion}\n\n")
        
        # Combine all content
        article["content"] = "".join(full_content)
        
        return article
    
    def generate_articles_from_outlines(self, outlines_dir, output_dir):
        """Generate articles from all outlines in a directory"""
        os.makedirs(output_dir, exist_ok=True)
        
        # Find all JSON files in the outlines directory
        outline_files = [f for f in os.listdir(outlines_dir) if f.endswith('.json') and f != 'summary.json']
        
        articles = []
        for file in outline_files:
            # Load the outline
            with open(os.path.join(outlines_dir, file), 'r') as f:
                outline = json.load(f)
                
            # Generate the article
            article = self.generate_article_from_outline(outline)
            articles.append(article)
            
            # Save as Markdown
            md_filename = file.replace('.json', '.md')
            with open(os.path.join(output_dir, md_filename), 'w') as f:
                f.write(article["content"])
                
            # Save as HTML
            html_filename = file.replace('.json', '.html')
            html_content = markdown.markdown(article["content"])
            with open(os.path.join(output_dir, html_filename), 'w') as f:
                f.write(f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{article["title"]}</title>
    <meta name="description" content="Learn all about {article['keyword']} in this comprehensive guide.">
    <meta name="keywords" content="{article['keyword']}, recipe, cooking, food">
    <style>
        body {{ font-family: Arial, sans-serif; line-height: 1.6; max-width: 800px; margin: 0 auto; padding: 20px; }}
        h1 {{ color: #333; }}
        h2 {{ color: #444; margin-top: 30px; }}
        p {{ margin-bottom: 20px; }}
    </style>
</head>
<body>
    {html_content}
</body>
</html>""")
            
            print(f"Generated article: {article['title']}")
            
        # Save a summary file
        summary = {
            "generated_date": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "article_count": len(articles),
            "articles": [{"title": a["title"], "keyword": a["keyword"]} for a in articles]
        }
        
        summary_path = os.path.join(output_dir, "summary.json")
        with open(summary_path, 'w') as f:
            json.dump(summary, f, indent=2)
            
        return articles

def main():
    print("Recipe Website Article Writer")
    print("============================")
    
    writer = ArticleWriter()
    
    # Ask for input
    outlines_dir = input("Outlines directory (default: ./article_outlines): ")
    outlines_dir = outlines_dir if outlines_dir else "./article_outlines"
    
    output_dir = input("Output directory (default: ./articles): ")
    output_dir = output_dir if output_dir else "./articles"
    
    # Check if outlines directory exists
    if not os.path.exists(outlines_dir):
        print(f"Error: Outlines directory '{outlines_dir}' does not exist.")
        return
    
    # Generate articles
    print(f"\nGenerating articles from outlines in {outlines_dir}...")
    articles = writer.generate_articles_from_outlines(outlines_dir, output_dir)
    
    # Print summary
    print("\nArticle Generation Complete!")
    print(f"Generated {len(articles)} articles:")
    for i, article in enumerate(articles):
        print(f"{i+1}. {article['title']}")
        
    print(f"\nAll articles saved to {output_dir}")
    print("You can now publish these articles to your website.")

if __name__ == "__main__":
    main()
