import os
import json
import shutil
from datetime import datetime

class WebsiteIntegrator:
    def __init__(self, website_root):
        self.website_root = website_root
        self.blog_dir = os.path.join(website_root, "src/app/blog")
        
    def integrate_article(self, article_path, slug=None):
        """Integrate an article into the website blog structure"""
        # Check if article exists
        if not os.path.exists(article_path):
            print(f"Error: Article file '{article_path}' does not exist.")
            return False
            
        # Determine if it's HTML or Markdown
        is_html = article_path.endswith('.html')
        
        # Read the article content
        with open(article_path, 'r') as f:
            content = f.read()
            
        # Extract title from the content
        if is_html:
            title_match = content.split('<title>')[1].split('</title>')[0] if '<title>' in content else "New Article"
        else:
            # For markdown, assume the first line is the title
            title_match = content.split('\n')[0].replace('# ', '') if content.startswith('# ') else "New Article"
            
        # Generate slug if not provided
        if not slug:
            slug = self._generate_slug(title_match)
            
        # Create directory for the article
        article_dir = os.path.join(self.blog_dir, slug)
        os.makedirs(article_dir, exist_ok=True)
        
        # Create the page.tsx file
        self._create_page_file(article_dir, title_match, content, is_html)
        
        print(f"Article integrated successfully at: {article_dir}")
        return True
        
    def integrate_multiple_articles(self, articles_dir):
        """Integrate multiple articles from a directory"""
        # Check if directory exists
        if not os.path.exists(articles_dir):
            print(f"Error: Articles directory '{articles_dir}' does not exist.")
            return False
            
        # Find all HTML and MD files
        html_files = [f for f in os.listdir(articles_dir) if f.endswith('.html') and f != 'index.html']
        md_files = [f for f in os.listdir(articles_dir) if f.endswith('.md')]
        
        # Prefer HTML files if both formats exist for the same article
        md_basenames = [os.path.splitext(f)[0] for f in md_files]
        html_files_to_use = html_files
        md_files_to_use = [f for f in md_files if os.path.splitext(f)[0] not in [os.path.splitext(h)[0] for h in html_files]]
        
        # Integrate HTML files
        for html_file in html_files_to_use:
            self.integrate_article(os.path.join(articles_dir, html_file))
            
        # Integrate MD files
        for md_file in md_files_to_use:
            self.integrate_article(os.path.join(articles_dir, md_file))
            
        print(f"Integrated {len(html_files_to_use) + len(md_files_to_use)} articles into the website.")
        return True
        
    def _generate_slug(self, title):
        """Generate a URL-friendly slug from a title"""
        # Convert to lowercase and replace spaces with hyphens
        slug = title.lower().replace(' ', '-')
        
        # Remove special characters
        slug = ''.join(c for c in slug if c.isalnum() or c == '-')
        
        # Remove multiple consecutive hyphens
        while '--' in slug:
            slug = slug.replace('--', '-')
            
        # Trim hyphens from beginning and end
        slug = slug.strip('-')
        
        return slug
        
    def _create_page_file(self, article_dir, title, content, is_html):
        """Create the page.tsx file for the article"""
        # Convert HTML content to JSX if needed
        if is_html:
            # Extract the body content
            body_content = content.split('<body>')[1].split('</body>')[0] if '<body>' in content else content
            
            # Create the page.tsx content
            page_content = f"""'use client';

import React from 'react';
import SectionHeader from '../../../components/SectionHeader';

export default function BlogPost() {{
  return (
    <main>
      <section className="bg-gray-100 py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <div className="bg-[rgb(var(--primary-color))] text-white px-3 py-1 text-sm inline-block mb-4">
              Recipe Tips
            </div>
            <h1 className="text-4xl font-bold mb-4">{title}</h1>
            <div className="flex items-center text-sm text-gray-600 mb-6">
              <span className="mr-4">{datetime.now().strftime("%B %d, %Y")}</span>
              <span>By Recipe Generator</span>
            </div>
          </div>
        </div>
      </section>

      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
            <div className="lg:col-span-2">
              <div className="prose prose-lg max-w-none">
                {body_content}
              </div>
              
              <div className="mt-12 pt-6 border-t border-gray-200">
                <h3 className="text-lg font-semibold mb-4">Share This Article</h3>
                <div className="flex space-x-4">
                  <button className="bg-blue-600 text-white p-2 rounded-full">
                    <span className="sr-only">Facebook</span>
                    <svg className="h-5 w-5" fill="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                      <path fillRule="evenodd" d="M22 12c0-5.523-4.477-10-10-10S2 6.477 2 12c0 4.991 3.657 9.128 8.438 9.878v-6.987h-2.54V12h2.54V9.797c0-2.506 1.492-3.89 3.777-3.89 1.094 0 2.238.195 2.238.195v2.46h-1.26c-1.243 0-1.63.771-1.63 1.562V12h2.773l-.443 2.89h-2.33v6.988C18.343 21.128 22 16.991 22 12z" clipRule="evenodd" />
                    </svg>
                  </button>
                  <button className="bg-blue-400 text-white p-2 rounded-full">
                    <span className="sr-only">Twitter</span>
                    <svg className="h-5 w-5" fill="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                      <path d="M8.29 20.251c7.547 0 11.675-6.253 11.675-11.675 0-.178 0-.355-.012-.53A8.348 8.348 0 0022 5.92a8.19 8.19 0 01-2.357.646 4.118 4.118 0 001.804-2.27 8.224 8.224 0 01-2.605.996 4.107 4.107 0 00-6.993 3.743 11.65 11.65 0 01-8.457-4.287 4.106 4.106 0 001.27 5.477A4.072 4.072 0 012.8 9.713v.052a4.105 4.105 0 003.292 4.022 4.095 4.095 0 01-1.853.07 4.108 4.108 0 003.834 2.85A8.233 8.233 0 012 18.407a11.616 11.616 0 006.29 1.84" />
                    </svg>
                  </button>
                </div>
              </div>
            </div>
            
            <div className="lg:col-span-1">
              <div className="bg-gray-50 p-6 rounded-lg mb-8">
                <h3 className="text-lg font-semibold mb-4">About Recipe Generator</h3>
                <p className="text-gray-600 text-sm">
                  Recipe Generator helps you discover delicious recipes using ingredients you already have at home.
                  Our AI-powered tool creates personalized recipe suggestions based on your available ingredients,
                  dietary preferences, and cooking style.
                </p>
              </div>
              
              <div>
                <h3 className="text-lg font-semibold mb-4">Try Our Recipe Generator</h3>
                <p className="text-gray-600 mb-4">
                  Enter the ingredients you have on hand and get instant recipe suggestions.
                </p>
                <a 
                  href="/#generator" 
                  className="bg-[rgb(var(--primary-color))] text-white py-2 px-4 rounded-md inline-block hover:bg-opacity-90 transition"
                >
                  Generate Recipes Now
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>
    </main>
  );
}}"""
        else:
            # For markdown, we'll use the dangerouslySetInnerHTML approach
            # First, convert markdown to HTML string representation
            md_content = json.dumps(content)
            
            page_content = f"""'use client';

import React from 'react';
import SectionHeader from '../../../components/SectionHeader';
import markdown from 'markdown-it';

export default function BlogPost() {{
  const md = markdown();
  const content = {md_content};
  const htmlContent = md.render(content);

  return (
    <main>
      <section className="bg-gray-100 py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <div className="bg-[rgb(var(--primary-color))] text-white px-3 py-1 text-sm inline-block mb-4">
              Recipe Tips
            </div>
            <h1 className="text-4xl font-bold mb-4">{title}</h1>
            <div className="flex items-center text-sm text-gray-600 mb-6">
              <span className="mr-4">{datetime.now().strftime("%B %d, %Y")}</span>
              <span>By Recipe Generator</span>
            </div>
          </div>
        </div>
      </section>

      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
            <div className="lg:col-span-2">
              <div className="prose prose-lg max-w-none" dangerouslySetInnerHTML={{ __html: htmlContent }}></div>
              
              <div className="mt-12 pt-6 border-t border-gray-200">
                <h3 className="text-lg font-semibold mb-4">Share This Article</h3>
                <div className="flex space-x-4">
                  <button className="bg-blue-600 text-white p-2 rounded-full">
                    <span className="sr-only">Facebook</span>
                    <svg className="h-5 w-5" fill="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                      <path fillRule="evenodd" d="M22 12c0-5.523-4.477-10-10-10S2 6.477 2 12c0 4.991 3.657 9.128 8.438 9.878v-6.987h-2.54V12h2.54V9.797c0-2.506 1.492-3.89 3.777-3.89 1.094 0 2.238.195 2.238.195v2.46h-1.26c-1.243 0-1.63.771-1.63 1.562V12h2.773l-.443 2.89h-2.33v6.988C18.343 21.128 22 16.991 22 12z" clipRule="evenodd" />
                    </svg>
                  </button>
                  <button className="bg-blue-400 text-white p-2 rounded-full">
                    <span className="sr-only">Twitter</span>
                    <svg className="h-5 w-5" fill="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                      <path d="M8.29 20.251c7.547 0 11.675-6.253 11.675-11.675 0-.178 0-.355-.012-.53A8.348 8.348 0 0022 5.92a8.19 8.19 0 01-2.357.646 4.118 4.118 0 001.804-2.27 8.224 8.224 0 01-2.605.996 4.107 4.107 0 00-6.993 3.743 11.65 11.65 0 01-8.457-4.287 4.106 4.106 0 001.27 5.477A4.072 4.072 0 012.8 9.713v.052a4.105 4.105 0 003.292 4.022 4.095 4.095 0 01-1.853.07 4.108 4.108 0 003.834 2.85A8.233 8.233 0 012 18.407a11.616 11.616 0 006.29 1.84" />
                    </svg>
                  </button>
                </div>
              </div>
            </div>
            
            <div className="lg:col-span-1">
              <div className="bg-gray-50 p-6 rounded-lg mb-8">
                <h3 className="text-lg font-semibold mb-4">About Recipe Generator</h3>
                <p className="text-gray-600 text-sm">
                  Recipe Generator helps you discover delicious recipes using ingredients you already have at home.
                  Our AI-powered tool creates personalized recipe suggestions based on your available ingredients,
                  dietary preferences, and cooking style.
                </p>
              </div>
              
              <div>
                <h3 className="text-lg font-semibold mb-4">Try Our Recipe Generator</h3>
                <p className="text-gray-600 mb-4">
                  Enter the ingredients you have on hand and get instant recipe suggestions.
                </p>
                <a 
                  href="/#generator" 
                  className="bg-[rgb(var(--primary-color))] text-white py-2 px-4 rounded-md inline-block hover:bg-opacity-90 transition"
                >
                  Generate Recipes Now
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>
    </main>
  );
}}"""
            
        # Write the page.tsx file
        with open(os.path.join(article_dir, 'page.tsx'), 'w') as f:
            f.write(page_content)

def main():
    print("Recipe Website Content Integrator")
    print("================================")
    
    # Ask for input
    website_root = input("Website root directory (default: ../recipe-generator): ")
    website_root = website_root if website_root else "../recipe-generator"
    
    articles_dir = input("Articles directory (default: ./articles): ")
    articles_dir = articles_dir if articles_dir else "./articles"
    
    # Check if directories exist
    if not os.path.exists(website_root):
        print(f"Error: Website root directory '{website_root}' does not exist.")
        return
        
    if not os.path.exists(articles_dir):
        print(f"Error: Articles directory '{articles_dir}' does not exist.")
        return
        
    # Create integrator
    integrator = WebsiteIntegrator(website_root)
    
    # Ask for integration mode
    mode = input("Integration mode (single/multiple): ").lower()
    
    if mode == 'single':
        # Ask for article file
        article_file = input("Article file path: ")
        if not os.path.exists(article_file):
            print(f"Error: Article file '{article_file}' does not exist.")
            return
            
        # Ask for slug
        slug = input("Slug for the article (leave empty for auto-generation): ")
        slug = slug if slug else None
        
        # Integrate article
        integrator.integrate_article(article_file, slug)
        
    elif mode == 'multiple':
        # Integrate all articles
        integrator.integrate_multiple_articles(articles_dir)
        
    else:
        print("Invalid mode. Please enter 'single' or 'multiple'.")
        return
        
    print("\nIntegration complete!")
    print("You can now build and deploy your website to see the new articles.")

if __name__ == "__main__":
    main()
