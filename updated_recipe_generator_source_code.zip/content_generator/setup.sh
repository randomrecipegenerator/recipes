#!/bin/bash

# Make the content generator script executable
chmod +x content_generator.py

# Check if Python and required packages are installed
echo "Checking dependencies..."

# Check for Python
if ! command -v python3 &> /dev/null; then
    echo "Python 3 is not installed. Installing..."
    sudo apt-get update
    sudo apt-get install -y python3 python3-pip
fi

# Install required packages
echo "Installing required Python packages..."
pip3 install markdown

echo "Setup complete! You can now use the content generator."
echo ""
echo "Usage examples:"
echo "  ./content_generator.py                       # Interactive menu"
echo "  ./content_generator.py keywords --count 5    # Generate 5 article outlines"
echo "  ./content_generator.py articles              # Generate articles from outlines"
echo "  ./content_generator.py pipeline --count 3    # Run full pipeline for 3 articles"
echo ""
echo "For more options, run: ./content_generator.py --help"
