# Recipe Generator Website Content Tool - User Guide

This guide explains how to use the content generation tool to create SEO-optimized articles for your recipe generator website.

## Overview

The content generation tool helps you:
1. Research trending keywords related to recipe generation
2. Create article outlines based on those keywords
3. Generate full articles from the outlines
4. Integrate the articles into your Next.js website

## Installation

1. Navigate to the content generator directory:
```
cd /path/to/recipe_generator_website/content_generator
```

2. Run the setup script to install dependencies:
```
bash setup.sh
```

3. Make the main script executable:
```
chmod +x content_generator.py
```

## Using the Tool

The tool can be used in three ways:
- Interactive menu mode
- Command-line mode
- Step-by-step mode

### Interactive Menu Mode

Run the tool without arguments to use the interactive menu:
```
./content_generator.py
```

Follow the on-screen prompts to:
1. Research keywords and generate article outlines
2. Generate articles from outlines
3. Run the full content generation pipeline

### Command-Line Mode

#### Research Keywords & Generate Outlines
```
./content_generator.py keywords --count 5 --output ./article_outlines
```

Options:
- `--seed`: Specific seed keyword to use (optional)
- `--count`: Number of articles to generate (default: 5)
- `--output`: Output directory for article outlines (default: ./article_outlines)

#### Generate Articles from Outlines
```
./content_generator.py articles --outlines ./article_outlines --output ./articles
```

Options:
- `--outlines`: Directory containing article outlines (default: ./article_outlines)
- `--output`: Output directory for generated articles (default: ./articles)

#### Run Full Pipeline
```
./content_generator.py pipeline --count 5 --outlines ./article_outlines --output ./articles
```

Options:
- `--seed`: Specific seed keyword to use (optional)
- `--count`: Number of articles to generate (default: 5)
- `--outlines`: Output directory for article outlines (default: ./article_outlines)
- `--output`: Output directory for generated articles (default: ./articles)

### Integrating Articles with Your Website

After generating articles, you can integrate them into your Next.js website:

```
python website_integrator.py
```

Follow the prompts to:
1. Specify your website root directory
2. Choose the articles directory
3. Select integration mode (single article or multiple articles)

## Workflow Example

Here's a typical workflow for generating 5 new articles:

1. Run the full pipeline:
```
./content_generator.py pipeline --count 5
```

2. Review the generated articles in the `./articles` directory

3. Integrate the articles with your website:
```
python website_integrator.py
```

4. Build and deploy your website to see the new articles

## Tips for Best Results

1. **Keyword Research**: For more targeted content, use specific seed keywords like "healthy recipe generator" or "vegetarian meal planner"

2. **Article Quality**: Review and edit generated articles before publishing to ensure they meet your quality standards

3. **Regular Content**: Aim to generate 5 new articles per week to maintain fresh content and improve SEO rankings

4. **SEO Optimization**: The tool automatically optimizes articles for SEO, but consider adding internal links between related articles

5. **Images**: Consider adding relevant images to your articles after integration to improve engagement

## Troubleshooting

- **Missing Dependencies**: Run `bash setup.sh` to install required packages
- **Permission Denied**: Run `chmod +x content_generator.py` to make the script executable
- **Integration Errors**: Ensure your website structure matches the expected Next.js structure

## Support

If you encounter any issues or have questions about using the content generation tool, please contact support at support@recipegenerator.example.com.
