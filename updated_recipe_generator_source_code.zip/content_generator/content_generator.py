#!/usr/bin/env python3
import os
import sys
import argparse
from keyword_research import ContentGenerator
from article_writer import ArticleWriter

def main():
    parser = argparse.ArgumentParser(description='Recipe Website Content Generator Tool')
    subparsers = parser.add_subparsers(dest='command', help='Command to run')
    
    # Keyword research command
    keyword_parser = subparsers.add_parser('keywords', help='Research keywords and generate article outlines')
    keyword_parser.add_argument('--seed', type=str, help='Seed keyword to use for research')
    keyword_parser.add_argument('--count', type=int, default=5, help='Number of articles to generate (default: 5)')
    keyword_parser.add_argument('--output', type=str, default='./article_outlines', help='Output directory for article outlines')
    
    # Article generation command
    article_parser = subparsers.add_parser('articles', help='Generate articles from outlines')
    article_parser.add_argument('--outlines', type=str, default='./article_outlines', help='Directory containing article outlines')
    article_parser.add_argument('--output', type=str, default='./articles', help='Output directory for generated articles')
    
    # Full pipeline command
    pipeline_parser = subparsers.add_parser('pipeline', help='Run the full content generation pipeline')
    pipeline_parser.add_argument('--seed', type=str, help='Seed keyword to use for research')
    pipeline_parser.add_argument('--count', type=int, default=5, help='Number of articles to generate (default: 5)')
    pipeline_parser.add_argument('--outlines', type=str, default='./article_outlines', help='Output directory for article outlines')
    pipeline_parser.add_argument('--output', type=str, default='./articles', help='Output directory for generated articles')
    
    # Parse arguments
    args = parser.parse_args()
    
    if args.command == 'keywords':
        run_keyword_research(args.seed, args.count, args.output)
    elif args.command == 'articles':
        generate_articles(args.outlines, args.output)
    elif args.command == 'pipeline':
        run_full_pipeline(args.seed, args.count, args.outlines, args.output)
    else:
        # If no command is provided, show interactive menu
        show_interactive_menu()

def run_keyword_research(seed_keyword, count, output_dir):
    """Run keyword research and generate article outlines"""
    print("\n=== Recipe Website Keyword Research ===")
    print(f"Generating {count} article outlines...")
    
    generator = ContentGenerator()
    outlines = generator.generate_content(count, seed_keyword)
    summary = generator.save_outlines(outlines, output_dir)
    
    print("\nKeyword Research Complete!")
    print(f"Generated {len(outlines)} article outlines:")
    for i, article in enumerate(summary["articles"]):
        print(f"{i+1}. {article['title']} (keyword: {article['keyword']})")
        
    print(f"\nAll outlines saved to {output_dir}")

def generate_articles(outlines_dir, output_dir):
    """Generate articles from outlines"""
    print("\n=== Recipe Website Article Generator ===")
    
    # Check if outlines directory exists
    if not os.path.exists(outlines_dir):
        print(f"Error: Outlines directory '{outlines_dir}' does not exist.")
        return
    
    writer = ArticleWriter()
    print(f"Generating articles from outlines in {outlines_dir}...")
    articles = writer.generate_articles_from_outlines(outlines_dir, output_dir)
    
    print("\nArticle Generation Complete!")
    print(f"Generated {len(articles)} articles:")
    for i, article in enumerate(articles):
        print(f"{i+1}. {article['title']}")
        
    print(f"\nAll articles saved to {output_dir}")

def run_full_pipeline(seed_keyword, count, outlines_dir, output_dir):
    """Run the full content generation pipeline"""
    print("\n=== Recipe Website Content Generation Pipeline ===")
    
    # Step 1: Keyword Research
    print("\nStep 1: Keyword Research")
    run_keyword_research(seed_keyword, count, outlines_dir)
    
    # Step 2: Article Generation
    print("\nStep 2: Article Generation")
    generate_articles(outlines_dir, output_dir)
    
    print("\nContent Generation Pipeline Complete!")
    print(f"Generated {count} articles based on keyword research.")
    print(f"Articles are ready for publishing to your website.")

def show_interactive_menu():
    """Show an interactive menu for the content generator"""
    while True:
        print("\n=== Recipe Website Content Generator ===")
        print("1. Research Keywords & Generate Article Outlines")
        print("2. Generate Articles from Outlines")
        print("3. Run Full Content Generation Pipeline")
        print("4. Exit")
        
        choice = input("\nEnter your choice (1-4): ")
        
        if choice == '1':
            seed = input("Do you want to use a specific seed keyword? (y/n): ").lower() == 'y'
            seed_keyword = input("Enter seed keyword: ") if seed else None
            count = input("How many articles to generate (default 5): ")
            count = int(count) if count.isdigit() else 5
            output_dir = input("Output directory (default: ./article_outlines): ")
            output_dir = output_dir if output_dir else "./article_outlines"
            
            run_keyword_research(seed_keyword, count, output_dir)
            
        elif choice == '2':
            outlines_dir = input("Outlines directory (default: ./article_outlines): ")
            outlines_dir = outlines_dir if outlines_dir else "./article_outlines"
            output_dir = input("Output directory (default: ./articles): ")
            output_dir = output_dir if output_dir else "./articles"
            
            generate_articles(outlines_dir, output_dir)
            
        elif choice == '3':
            seed = input("Do you want to use a specific seed keyword? (y/n): ").lower() == 'y'
            seed_keyword = input("Enter seed keyword: ") if seed else None
            count = input("How many articles to generate (default 5): ")
            count = int(count) if count.isdigit() else 5
            outlines_dir = input("Outlines directory (default: ./article_outlines): ")
            outlines_dir = outlines_dir if outlines_dir else "./article_outlines"
            output_dir = input("Output directory (default: ./articles): ")
            output_dir = output_dir if output_dir else "./articles"
            
            run_full_pipeline(seed_keyword, count, outlines_dir, output_dir)
            
        elif choice == '4':
            print("Exiting Content Generator. Goodbye!")
            break
            
        else:
            print("Invalid choice. Please enter a number between 1 and 4.")

if __name__ == "__main__":
    main()
