import requests
import json
import random
from datetime import datetime
import os
import re
import time

class KeywordResearcher:
    def __init__(self):
        self.recipe_keywords = [
            "recipe generator", "AI recipe generator", "find recipes by ingredients",
            "what to cook with ingredients at home", "recipe finder", "meal ideas generator",
            "random recipe generator", "recipe creator", "cooking with ingredients on hand",
            "recipe suggestions", "leftover ingredients recipes", "quick meal ideas",
            "easy dinner recipes", "healthy recipe generator", "vegetarian recipe finder",
            "vegan recipes with ingredients", "gluten-free recipe generator",
            "keto recipe finder", "meal planner with ingredients", "dinner ideas generator"
        ]
        
    def search_related_keywords(self, seed_keyword):
        """Search for keywords related to the seed keyword"""
        print(f"Researching keywords related to: {seed_keyword}")
        
        # Simulate API call to get related keywords
        related_keywords = []
        
        # Add variations of the seed keyword
        base_variations = [
            f"best {seed_keyword}",
            f"{seed_keyword} online",
            f"free {seed_keyword}",
            f"{seed_keyword} app",
            f"{seed_keyword} website",
            f"how to use {seed_keyword}",
            f"{seed_keyword} for beginners",
            f"{seed_keyword} review"
        ]
        related_keywords.extend(base_variations)
        
        # Add more specific recipe-related variations
        if "recipe" in seed_keyword:
            recipe_variations = [
                seed_keyword.replace("recipe", "meal"),
                seed_keyword.replace("recipe", "cooking"),
                seed_keyword.replace("recipe", "food"),
                f"{seed_keyword} with photos",
                f"{seed_keyword} with ratings",
                f"popular {seed_keyword}",
                f"trending {seed_keyword}",
                f"seasonal {seed_keyword}"
            ]
            related_keywords.extend(recipe_variations)
        
        # Add ingredient-focused variations
        if "ingredient" in seed_keyword:
            ingredient_variations = [
                seed_keyword.replace("ingredient", "pantry item"),
                seed_keyword.replace("ingredient", "food"),
                f"{seed_keyword} in fridge",
                f"{seed_keyword} on hand",
                f"using leftover {seed_keyword}",
                f"what to cook with available {seed_keyword}",
                f"recipes based on {seed_keyword}"
            ]
            related_keywords.extend(ingredient_variations)
            
        # Filter out duplicates and clean up
        related_keywords = list(set(related_keywords))
        related_keywords = [kw for kw in related_keywords if len(kw.split()) <= 5]  # Keep reasonable length
        
        # Add search volume and competition metrics (simulated)
        keyword_data = []
        for kw in related_keywords:
            search_volume = random.randint(1000, 50000)
            competition = round(random.uniform(0.1, 0.9), 2)
            keyword_data.append({
                "keyword": kw,
                "search_volume": search_volume,
                "competition": competition,
                "score": search_volume * (1 - competition)  # Higher score = better keyword
            })
            
        # Sort by score (descending)
        keyword_data.sort(key=lambda x: x["score"], reverse=True)
        
        return keyword_data[:20]  # Return top 20 keywords
    
    def get_trending_recipe_keywords(self):
        """Get trending recipe keywords"""
        print("Researching trending recipe keywords...")
        
        # Start with seed keywords
        all_keywords = []
        
        # Research related keywords for each seed keyword
        for seed in random.sample(self.recipe_keywords, 3):  # Take 3 random seed keywords
            related = self.search_related_keywords(seed)
            all_keywords.extend(related)
            
        # Sort by score
        all_keywords.sort(key=lambda x: x["score"], reverse=True)
        
        # Return top keywords
        return all_keywords[:15]  # Return top 15 keywords

class ArticleGenerator:
    def __init__(self):
        self.article_templates = [
            {
                "type": "list",
                "title_template": "{number} {adjective} {keyword} You Need to Try",
                "sections": [
                    "Introduction",
                    "Why {keyword} Matters",
                    "{number} {adjective} {keyword}",
                    "How to Get Started with {keyword}",
                    "Conclusion"
                ]
            },
            {
                "type": "how-to",
                "title_template": "How to {keyword}: A Complete Guide",
                "sections": [
                    "Introduction",
                    "What is {keyword}?",
                    "Benefits of {keyword}",
                    "Step-by-Step Guide to {keyword}",
                    "Common Mistakes to Avoid",
                    "Conclusion"
                ]
            },
            {
                "type": "review",
                "title_template": "{keyword} Review: Is It Worth It?",
                "sections": [
                    "Introduction",
                    "What is {keyword}?",
                    "Features and Benefits",
                    "Pros and Cons",
                    "Who Should Use {keyword}?",
                    "Conclusion"
                ]
            },
            {
                "type": "comparison",
                "title_template": "{keyword} vs. Alternatives: Which is Best?",
                "sections": [
                    "Introduction",
                    "Overview of {keyword}",
                    "Top Alternatives to {keyword}",
                    "Feature Comparison",
                    "Which One Should You Choose?",
                    "Conclusion"
                ]
            },
            {
                "type": "ultimate-guide",
                "title_template": "The Ultimate Guide to {keyword}",
                "sections": [
                    "Introduction",
                    "What is {keyword}?",
                    "Why {keyword} Matters",
                    "How to Get Started with {keyword}",
                    "Advanced {keyword} Techniques",
                    "Tools and Resources",
                    "Conclusion"
                ]
            }
        ]
        
        self.adjectives = [
            "Amazing", "Incredible", "Delicious", "Easy", "Quick", "Healthy", 
            "Simple", "Tasty", "Fantastic", "Nutritious", "Creative", "Innovative",
            "Time-Saving", "Budget-Friendly", "Family-Friendly", "Seasonal",
            "Popular", "Trending", "Must-Try", "Game-Changing"
        ]
        
        self.numbers = ["5", "7", "10", "12", "15", "20"]
        
    def generate_article_outline(self, keyword_data):
        """Generate an article outline based on keyword data"""
        keyword = keyword_data["keyword"]
        
        # Choose a random template
        template = random.choice(self.article_templates)
        
        # Format the title
        title = template["title_template"]
        if "{adjective}" in title:
            title = title.replace("{adjective}", random.choice(self.adjectives))
        if "{number}" in title:
            title = title.replace("{number}", random.choice(self.numbers))
        title = title.replace("{keyword}", keyword)
        
        # Format the sections
        sections = []
        for section in template["sections"]:
            formatted_section = section.replace("{keyword}", keyword)
            if "{adjective}" in formatted_section:
                formatted_section = formatted_section.replace("{adjective}", random.choice(self.adjectives))
            if "{number}" in formatted_section:
                formatted_section = formatted_section.replace("{number}", random.choice(self.numbers))
            sections.append(formatted_section)
        
        # Create the outline
        outline = {
            "title": title,
            "keyword": keyword,
            "search_volume": keyword_data["search_volume"],
            "competition": keyword_data["competition"],
            "score": keyword_data["score"],
            "type": template["type"],
            "sections": sections,
            "date": datetime.now().strftime("%Y-%m-%d")
        }
        
        return outline
    
    def generate_article_outlines(self, keywords, count=5):
        """Generate multiple article outlines"""
        outlines = []
        
        # Ensure we have enough keywords
        if len(keywords) < count:
            print(f"Warning: Only {len(keywords)} keywords available, requested {count} articles")
            count = len(keywords)
        
        # Generate outlines for the top keywords
        for i in range(count):
            outline = self.generate_article_outline(keywords[i])
            outlines.append(outline)
            
        return outlines

class ContentGenerator:
    def __init__(self):
        self.keyword_researcher = KeywordResearcher()
        self.article_generator = ArticleGenerator()
        
    def generate_content(self, count=5, seed_keyword=None):
        """Generate content based on keyword research"""
        # Step 1: Research keywords
        if seed_keyword:
            keywords = self.keyword_researcher.search_related_keywords(seed_keyword)
        else:
            keywords = self.keyword_researcher.get_trending_recipe_keywords()
            
        # Step 2: Generate article outlines
        outlines = self.article_generator.generate_article_outlines(keywords, count)
        
        return outlines
    
    def save_outlines(self, outlines, output_dir):
        """Save article outlines to files"""
        os.makedirs(output_dir, exist_ok=True)
        
        # Save each outline to a separate file
        for i, outline in enumerate(outlines):
            # Create a filename based on the title
            filename = re.sub(r'[^\w\s-]', '', outline["title"]).strip().lower()
            filename = re.sub(r'[-\s]+', '-', filename)
            filepath = os.path.join(output_dir, f"{filename}.json")
            
            # Save the outline as JSON
            with open(filepath, 'w') as f:
                json.dump(outline, f, indent=2)
                
            print(f"Saved outline to {filepath}")
            
        # Save a summary file
        summary = {
            "generated_date": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "article_count": len(outlines),
            "articles": [{"title": o["title"], "keyword": o["keyword"]} for o in outlines]
        }
        
        summary_path = os.path.join(output_dir, "summary.json")
        with open(summary_path, 'w') as f:
            json.dump(summary, f, indent=2)
            
        print(f"Saved summary to {summary_path}")
        
        return summary

def main():
    print("Recipe Website Content Generator")
    print("===============================")
    
    generator = ContentGenerator()
    
    # Ask for input
    use_seed = input("Do you want to use a specific seed keyword? (y/n): ").lower() == 'y'
    
    if use_seed:
        seed_keyword = input("Enter seed keyword: ")
    else:
        seed_keyword = None
        
    count = input("How many articles to generate (default 5): ")
    count = int(count) if count.isdigit() else 5
    
    output_dir = input("Output directory (default: ./article_outlines): ")
    output_dir = output_dir if output_dir else "./article_outlines"
    
    # Generate content
    print(f"\nGenerating {count} article outlines...")
    outlines = generator.generate_content(count, seed_keyword)
    
    # Save outlines
    summary = generator.save_outlines(outlines, output_dir)
    
    # Print summary
    print("\nGeneration Complete!")
    print(f"Generated {len(outlines)} article outlines:")
    for i, article in enumerate(summary["articles"]):
        print(f"{i+1}. {article['title']} (keyword: {article['keyword']})")
        
    print(f"\nAll outlines saved to {output_dir}")
    print("You can now use these outlines to create full articles for your website.")

if __name__ == "__main__":
    main()
