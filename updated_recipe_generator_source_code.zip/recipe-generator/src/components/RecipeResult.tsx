'use client';

import React from 'react';

interface RecipeResultProps {
  title: string;
  ingredients: string[];
  instructions: string[];
  prepTime: string;
  cookTime: string;
  servings: number;
  cuisine: string;
  mealType: string;
  dietaryInfo?: string;
  image?: string;
}

export default function RecipeResult({
  title,
  ingredients,
  instructions,
  prepTime,
  cookTime,
  servings,
  cuisine,
  mealType,
  dietaryInfo,
  image = '/images/recipe-placeholder.jpg'
}: RecipeResultProps) {
  return (
    <div className="recipe-result">
      <div className="flex flex-col md:flex-row gap-6">
        <div className="md:w-1/3">
          <div className="bg-gray-200 rounded-lg h-64 mb-4">
            {/* Image would be added here in production */}
            <div className="w-full h-full flex items-center justify-center text-gray-400">
              {image ? <img src={image} alt={title} className="w-full h-full object-cover rounded-lg" /> : "Recipe Image"}
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4 mb-4">
            <div className="text-center p-3 bg-gray-50 rounded-lg">
              <p className="text-sm text-gray-500">Prep Time</p>
              <p className="font-semibold">{prepTime}</p>
            </div>
            <div className="text-center p-3 bg-gray-50 rounded-lg">
              <p className="text-sm text-gray-500">Cook Time</p>
              <p className="font-semibold">{cookTime}</p>
            </div>
            <div className="text-center p-3 bg-gray-50 rounded-lg">
              <p className="text-sm text-gray-500">Servings</p>
              <p className="font-semibold">{servings}</p>
            </div>
            <div className="text-center p-3 bg-gray-50 rounded-lg">
              <p className="text-sm text-gray-500">Cuisine</p>
              <p className="font-semibold">{cuisine}</p>
            </div>
          </div>
          {dietaryInfo && (
            <div className="bg-[rgba(var(--primary-color),0.1)] text-[rgb(var(--primary-color))] p-2 rounded-lg text-center mb-4">
              {dietaryInfo}
            </div>
          )}
          <div className="flex space-x-2">
            <button className="secondary-button flex-1 py-2 text-sm">Save Recipe</button>
            <button className="bg-gray-200 hover:bg-gray-300 text-gray-700 py-2 px-4 rounded-md text-sm">
              Share
            </button>
          </div>
        </div>
        
        <div className="md:w-2/3">
          <h2 className="text-2xl font-bold mb-4">{title}</h2>
          <div className="mb-6">
            <h3 className="text-lg font-semibold mb-2">Ingredients</h3>
            <ul className="list-disc pl-5 space-y-1">
              {ingredients.map((ingredient, index) => (
                <li key={index} className="text-gray-700">{ingredient}</li>
              ))}
            </ul>
          </div>
          <div>
            <h3 className="text-lg font-semibold mb-2">Instructions</h3>
            <ol className="list-decimal pl-5 space-y-3">
              {instructions.map((step, index) => (
                <li key={index} className="text-gray-700">{step}</li>
              ))}
            </ol>
          </div>
        </div>
      </div>
    </div>
  );
}
