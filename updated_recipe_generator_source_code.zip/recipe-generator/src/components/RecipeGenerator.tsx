'use client';

import React, { useState } from 'react';
import RecipeResult from './RecipeResult';
import RecipeGeneratorAPI from '../lib/recipeGeneratorAPI';

export default function RecipeGenerator() {
  const [ingredients, setIngredients] = useState('');
  const [cuisine, setCuisine] = useState('Any Cuisine');
  const [mealType, setMealType] = useState('Any Meal');
  const [dietaryOptions, setDietaryOptions] = useState('No Restrictions');
  const [isLoading, setIsLoading] = useState(false);
  const [recipe, setRecipe] = useState(null);
  const [error, setError] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsLoading(true);
    setError('');
    
    try {
      const api = RecipeGeneratorAPI();
      const result = await api.generateRecipe(ingredients, cuisine, mealType, dietaryOptions);
      setRecipe(result);
    } catch (err) {
      setError('Failed to generate recipe. Please try again.');
      console.error('Recipe generation error:', err);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div>
      {!recipe ? (
        <div className="p-6 bg-white rounded-lg shadow-md">
          <h2 className="text-2xl font-bold mb-6">AI Recipe Generator</h2>
          
          <form onSubmit={handleSubmit}>
            <div className="mb-6">
              <label htmlFor="ingredients" className="block mb-2 font-medium">Ingredients</label>
              <input 
                type="text" 
                id="ingredients"
                className="input-field"
                placeholder="Enter ingredients or type 'surprise me' for completely random recipes..."
                value={ingredients}
                onChange={(e) => setIngredients(e.target.value)}
              />
              <p className="text-sm text-gray-500 mt-1">Enter ingredients, dish types, or any keywords for your recipe</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
              <div>
                <label htmlFor="cuisine" className="block mb-2 font-medium">Cuisine</label>
                <select 
                  id="cuisine" 
                  className="select-field"
                  value={cuisine}
                  onChange={(e) => setCuisine(e.target.value)}
                >
                  <option>Any Cuisine</option>
                  <option>Italian</option>
                  <option>Mexican</option>
                  <option>Chinese</option>
                  <option>Indian</option>
                  <option>Japanese</option>
                  <option>Thai</option>
                  <option>Mediterranean</option>
                  <option>American</option>
                  <option>French</option>
                </select>
              </div>
              <div>
                <label htmlFor="mealType" className="block mb-2 font-medium">Meal Type</label>
                <select 
                  id="mealType" 
                  className="select-field"
                  value={mealType}
                  onChange={(e) => setMealType(e.target.value)}
                >
                  <option>Any Meal</option>
                  <option>Breakfast</option>
                  <option>Lunch</option>
                  <option>Dinner</option>
                  <option>Dessert</option>
                  <option>Snack</option>
                  <option>Appetizer</option>
                  <option>Side Dish</option>
                </select>
              </div>
              <div>
                <label htmlFor="dietary" className="block mb-2 font-medium">Dietary Options</label>
                <select 
                  id="dietary" 
                  className="select-field"
                  value={dietaryOptions}
                  onChange={(e) => setDietaryOptions(e.target.value)}
                >
                  <option>No Restrictions</option>
                  <option>Vegetarian</option>
                  <option>Vegan</option>
                  <option>Gluten-Free</option>
                  <option>Dairy-Free</option>
                  <option>Keto</option>
                  <option>Low-Carb</option>
                  <option>Paleo</option>
                </select>
              </div>
            </div>

            <button 
              type="submit" 
              className="primary-button w-full py-3"
              disabled={isLoading}
            >
              {isLoading ? 'Generating Recipe...' : 'Generate Random Recipes Now'}
            </button>
            
            {error && (
              <p className="mt-4 text-red-500 text-center">{error}</p>
            )}
          </form>
        </div>
      ) : (
        <div>
          <RecipeResult {...recipe} />
          <div className="mt-6 text-center">
            <button 
              onClick={() => setRecipe(null)} 
              className="secondary-button"
            >
              Generate Another Recipe
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
