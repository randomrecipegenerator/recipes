import React from 'react';

interface CTASectionProps {
  title: string;
  subtitle: string;
  buttonText: string;
  buttonHref: string;
  backgroundColor?: string;
}

export default function CTASection({ 
  title, 
  subtitle, 
  buttonText, 
  buttonHref,
  backgroundColor = 'rgb(var(--primary-color))'
}: CTASectionProps) {
  return (
    <section className="py-16 text-white text-center" style={{ backgroundColor }}>
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold mb-4">{title}</h2>
        <p className="text-xl mb-8">{subtitle}</p>
        <a 
          href={buttonHref} 
          className="bg-white text-[rgb(var(--primary-color))] py-3 px-8 rounded-md font-semibold hover:bg-gray-100 transition"
        >
          {buttonText}
        </a>
      </div>
    </section>
  );
}
