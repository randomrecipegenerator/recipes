import React from 'react';

interface BlogPostCardProps {
  title: string;
  excerpt: string;
  date: string;
  author: string;
  slug: string;
  category: string;
  image?: string;
}

export default function BlogPostCard({ 
  title, 
  excerpt, 
  date, 
  author, 
  slug, 
  category,
  image = '/images/blog-placeholder.jpg'
}: BlogPostCardProps) {
  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden">
      <div className="h-48 bg-gray-200 relative">
        <div className="absolute top-0 right-0 bg-[rgb(var(--primary-color))] text-white px-3 py-1 text-sm">
          {category}
        </div>
        {/* Image would be added here in production */}
        <div className="w-full h-full flex items-center justify-center text-gray-400">
          {image ? <img src={image} alt={title} className="w-full h-full object-cover" /> : "Image Placeholder"}
        </div>
      </div>
      <div className="p-6">
        <h3 className="text-xl font-semibold mb-2">
          <a href={`/blog/${slug}`} className="hover:text-[rgb(var(--primary-color))]">
            {title}
          </a>
        </h3>
        <p className="text-gray-600 mb-4">{excerpt}</p>
        <div className="flex justify-between items-center text-sm text-gray-500">
          <span>{date}</span>
          <span>By {author}</span>
        </div>
      </div>
    </div>
  );
}
