import React from 'react';

interface FAQItemProps {
  question: string;
  answer: string;
}

export default function FAQItem({ question, answer }: FAQItemProps) {
  return (
    <div className="faq-item">
      <h3 className="faq-question">{question}</h3>
      <p className="mt-2 text-gray-600">{answer}</p>
    </div>
  );
}
