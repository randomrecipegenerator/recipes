import React from 'react';

interface HeroSectionProps {
  title: string;
  subtitle: string;
  primaryCTA: {
    text: string;
    href: string;
  };
  secondaryCTA?: {
    text: string;
    href: string;
  };
  backgroundImage?: string;
}

export default function HeroSection({ 
  title, 
  subtitle, 
  primaryCTA, 
  secondaryCTA,
  backgroundImage = '/images/kitchen-background.jpg'
}: HeroSectionProps) {
  const heroStyle = {
    backgroundImage: `linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), url('${backgroundImage}')`,
  };

  return (
    <section className="hero-section py-20 text-center" style={heroStyle}>
      <div className="container mx-auto px-4">
        <div className="bg-black bg-opacity-50 p-8 rounded-lg max-w-3xl mx-auto">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">{title}</h1>
          <p className="text-xl mb-8">{subtitle}</p>
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <a href={primaryCTA.href} className="primary-button">{primaryCTA.text}</a>
            {secondaryCTA && (
              <a href={secondaryCTA.href} className="secondary-button">{secondaryCTA.text}</a>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}
