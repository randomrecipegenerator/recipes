import React from 'react';
import RecipeResult from '../components/RecipeResult';

export default function RecipeResultPage() {
  // Sample recipe data
  const sampleRecipe = {
    title: "Garlic Butter Shrimp Pasta",
    ingredients: [
      "8 oz linguine pasta",
      "1 lb large shrimp, peeled and deveined",
      "4 tbsp butter",
      "4 cloves garlic, minced",
      "1/2 tsp red pepper flakes",
      "1/4 cup white wine",
      "2 tbsp lemon juice",
      "1/4 cup chopped parsley",
      "Salt and pepper to taste",
      "Grated Parmesan cheese for serving"
    ],
    instructions: [
      "Cook pasta according to package directions until al dente. Reserve 1/2 cup pasta water before draining.",
      "In a large skillet, melt 2 tablespoons of butter over medium-high heat.",
      "Add shrimp, season with salt and pepper, and cook for 1-2 minutes per side until pink and opaque. Remove shrimp and set aside.",
      "In the same skillet, add remaining butter, garlic, and red pepper flakes. Cook for 1 minute until fragrant.",
      "Add white wine and lemon juice, simmer for 2 minutes.",
      "Return shrimp to the skillet, add drained pasta and toss to combine. Add pasta water as needed to create a silky sauce.",
      "Stir in chopped parsley and adjust seasoning if needed.",
      "Serve immediately with grated Parmesan cheese on top."
    ],
    prepTime: "10 minutes",
    cookTime: "15 minutes",
    servings: 4,
    cuisine: "Italian",
    mealType: "Dinner",
    dietaryInfo: "Pescatarian"
  };

  return (
    <main>
      <section className="py-16">
        <div className="container mx-auto px-4">
          <h1 className="text-3xl font-bold mb-8 text-center">Your Generated Recipe</h1>
          <div className="max-w-4xl mx-auto">
            <RecipeResult {...sampleRecipe} />
          </div>
        </div>
      </section>
    </main>
  );
}
