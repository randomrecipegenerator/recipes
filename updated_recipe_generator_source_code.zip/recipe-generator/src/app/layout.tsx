import type { Metadata } from "next";
import { Inter } from "next/font/google";
import "./globals.css";

const inter = Inter({ subsets: ["latin"] });

export const metadata: Metadata = {
  title: "AI Recipe Generator | Find Recipes With Ingredients You Have",
  description: "Our AI-powered recipe generator creates personalized recipes instantly from any ingredients in your kitchen. 100% free to use!",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body className={inter.className}>
        <header className="bg-white shadow-sm">
          <div className="container mx-auto px-4 py-4 flex justify-between items-center">
            <div className="flex items-center">
              <h1 className="text-xl font-bold text-[rgb(var(--primary-color))]">Recipe Generator</h1>
            </div>
            <nav>
              <ul className="flex space-x-6">
                <li><a href="/" className="hover:text-[rgb(var(--primary-color))]">Home</a></li>
                <li><a href="/blog" className="hover:text-[rgb(var(--primary-color))]">Blog</a></li>
                <li><a href="/faq" className="hover:text-[rgb(var(--primary-color))]">FAQ</a></li>
                <li><a href="/about" className="hover:text-[rgb(var(--primary-color))]">About</a></li>
                <li><a href="/contact" className="hover:text-[rgb(var(--primary-color))]">Contact</a></li>
              </ul>
            </nav>
            <a href="#generator" className="primary-button">Try Our Recipe Generator Free</a>
          </div>
        </header>
        {children}
        <footer className="bg-gray-100 py-8">
          <div className="container mx-auto px-4">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
              <div>
                <h3 className="text-lg font-semibold mb-4">Recipe Generator</h3>
                <p className="text-sm text-gray-600">Our AI-powered recipe generator creates personalized recipes instantly from any ingredients in your kitchen.</p>
              </div>
              <div>
                <h3 className="text-lg font-semibold mb-4">Quick Links</h3>
                <ul className="space-y-2 text-sm">
                  <li><a href="/" className="text-gray-600 hover:text-[rgb(var(--primary-color))]">Home</a></li>
                  <li><a href="/blog" className="text-gray-600 hover:text-[rgb(var(--primary-color))]">Blog</a></li>
                  <li><a href="/faq" className="text-gray-600 hover:text-[rgb(var(--primary-color))]">FAQ</a></li>
                  <li><a href="/about" className="text-gray-600 hover:text-[rgb(var(--primary-color))]">About</a></li>
                  <li><a href="/contact" className="text-gray-600 hover:text-[rgb(var(--primary-color))]">Contact</a></li>
                </ul>
              </div>
              <div>
                <h3 className="text-lg font-semibold mb-4">Features</h3>
                <ul className="space-y-2 text-sm">
                  <li><a href="#" className="text-gray-600 hover:text-[rgb(var(--primary-color))]">AI-powered recipes</a></li>
                  <li><a href="#" className="text-gray-600 hover:text-[rgb(var(--primary-color))]">Ingredient-based search</a></li>
                  <li><a href="#" className="text-gray-600 hover:text-[rgb(var(--primary-color))]">Dietary restrictions</a></li>
                  <li><a href="#" className="text-gray-600 hover:text-[rgb(var(--primary-color))]">Cuisine filters</a></li>
                </ul>
              </div>
              <div>
                <h3 className="text-lg font-semibold mb-4">Connect</h3>
                <ul className="space-y-2 text-sm">
                  <li><a href="#" className="text-gray-600 hover:text-[rgb(var(--primary-color))]">Facebook</a></li>
                  <li><a href="#" className="text-gray-600 hover:text-[rgb(var(--primary-color))]">Twitter</a></li>
                  <li><a href="#" className="text-gray-600 hover:text-[rgb(var(--primary-color))]">Instagram</a></li>
                  <li><a href="#" className="text-gray-600 hover:text-[rgb(var(--primary-color))]">Pinterest</a></li>
                </ul>
              </div>
            </div>
            <div className="border-t border-gray-200 mt-8 pt-6 text-center text-sm text-gray-600">
              <p>&copy; {new Date().getFullYear()} Recipe Generator. All rights reserved.</p>
            </div>
          </div>
        </footer>
      </body>
    </html>
  );
}
