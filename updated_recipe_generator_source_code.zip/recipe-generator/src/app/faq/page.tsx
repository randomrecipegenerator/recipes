import React from 'react';
import SectionHeader from '../../components/SectionHeader';
import FAQItem from '../../components/FAQItem';
import CTASection from '../../components/CTASection';

export default function FAQ() {
  // FAQ items with questions and answers
  const faqItems = [
    {
      question: "What is a Recipe Generator?",
      answer: "A Recipe Generator is an online tool that creates recipes based on inputs like ingredients you have, cuisine preferences, or dietary restrictions. Our AI-powered Recipe Generator helps you discover new meal ideas using ingredients you already have in your kitchen, reducing food waste and inspiring culinary creativity."
    },
    {
      question: "How does this Recipe Generator work?",
      answer: "Our Recipe Generator uses advanced AI technology to create personalized recipes. Simply enter the ingredients you have on hand, select your preferred cuisine type and meal category, specify any dietary restrictions, and click 'Generate Random Recipes Now'. The AI will instantly create unique recipe suggestions tailored to your inputs."
    },
    {
      question: "Is this Recipe Generator completely free?",
      answer: "Yes! Our Recipe Generator is 100% free to use with no limitations. You can generate as many recipes as you want without any cost or subscription required. We believe everyone should have access to creative cooking solutions."
    },
    {
      question: "Why use a Recipe Generator?",
      answer: "A Recipe Generator helps break cooking routines and inspires creativity in the kitchen. It's particularly useful when you have random ingredients to use up, when you're bored with your usual meals, or when you want to try something new but don't know where to start. It can also help reduce food waste by suggesting recipes using ingredients you already have."
    },
    {
      question: "How accurate are the recipes?",
      answer: "Our AI is trained on thousands of recipes to ensure that the combinations it suggests are practical and delicious. However, as with any AI-generated content, we recommend using your cooking knowledge to adjust as needed. The recipes provide a solid foundation that you can customize to your taste."
    },
    {
      question: "Can I save my generated recipes?",
      answer: "Currently, you can copy and save the recipes manually. We're working on adding a feature to save your favorite generated recipes directly on our platform, which will be available in a future update."
    },
    {
      question: "What if I have dietary restrictions?",
      answer: "Our Recipe Generator includes options for various dietary restrictions including vegetarian, vegan, gluten-free, dairy-free, keto, low-carb, and paleo diets. Simply select your dietary preference from the dropdown menu before generating recipes."
    },
    {
      question: "Can I specify a cuisine type?",
      answer: "Yes! You can select from a variety of cuisine types including Italian, Mexican, Chinese, Indian, Japanese, Thai, Mediterranean, American, and French. If you don't have a preference, select 'Any Cuisine' for a wider range of recipe suggestions."
    },
    {
      question: "What if I don't have many ingredients?",
      answer: "Our Recipe Generator works with any number of ingredients. Even with just a few basic items, it can suggest creative recipes. You can also type 'surprise me' in the ingredients field for completely random recipe suggestions if you're open to buying new ingredients."
    },
    {
      question: "How do I get the best results from the Recipe Generator?",
      answer: "For best results, be specific about the ingredients you have, especially proteins and main vegetables. Include any herbs, spices, or condiments you have available. Select appropriate cuisine and meal types to narrow down the suggestions. If you're flexible, leaving these as 'Any' can lead to more creative and unexpected combinations."
    },
    {
      question: "Can I use the Recipe Generator for meal planning?",
      answer: "Absolutely! The Recipe Generator is perfect for meal planning. You can generate multiple recipes in one session to plan your meals for the week. This is especially useful for using up ingredients efficiently and reducing grocery shopping trips."
    },
    {
      question: "Is the Recipe Generator suitable for beginners?",
      answer: "Yes, our Recipe Generator is designed to be user-friendly for cooks of all skill levels. The generated recipes include clear instructions and measurements. If you're a beginner, you might want to start with simpler recipes by specifying 'easy' or 'quick' in your search terms."
    }
  ];

  return (
    <main>
      {/* Hero Section */}
      <section className="bg-gray-100 py-16">
        <div className="container mx-auto px-4">
          <h1 className="text-4xl font-bold mb-4">Frequently Asked Questions</h1>
          <p className="text-xl text-gray-600">Everything you need to know about our AI Recipe Generator</p>
        </div>
      </section>

      {/* FAQ Content */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <SectionHeader title="Recipe Generator FAQs" centered={false} />
          <div className="max-w-3xl mx-auto">
            {faqItems.map((item, index) => (
              <div key={index} className="mb-8 pb-8 border-b border-gray-200 last:border-0">
                <FAQItem question={item.question} answer={item.answer} />
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <CTASection 
        title="Ready to Try Our Recipe Generator?"
        subtitle="Generate personalized recipes based on ingredients you have at home"
        buttonText="Try It Now - 100% Free"
        buttonHref="/#generator"
      />

      {/* Contact Section */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="max-w-xl mx-auto text-center">
            <SectionHeader 
              title="Still Have Questions?" 
              subtitle="If you couldn't find the answer to your question, feel free to contact us"
            />
            <a href="/contact" className="secondary-button">Contact Us</a>
          </div>
        </div>
      </section>
    </main>
  );
}
