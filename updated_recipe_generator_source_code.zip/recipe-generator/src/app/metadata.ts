// SEO metadata for the website

export const siteMetadata = {
  title: "Recipe Generator | Find Recipes With Ingredients You Have",
  description: "Our AI-powered recipe generator creates personalized recipes instantly from any ingredients in your kitchen. 100% free to use!",
  keywords: "recipe generator, AI recipe generator, find recipes by ingredients, what to cook with ingredients at home, recipe finder, meal ideas generator, random recipe generator, recipe creator, cooking with ingredients on hand, recipe suggestions",
  author: "Recipe Generator",
  siteUrl: "https://recipegenerator.example.com",
  twitterHandle: "@recipegenerator",
  language: "en",
};

export const pageMetadata = {
  home: {
    title: "AI Recipe Generator | Find Recipes With Ingredients You Have",
    description: "Our AI-powered recipe generator creates personalized recipes instantly from any ingredients in your kitchen. 100% free to use!",
    keywords: "recipe generator, AI recipe generator, find recipes by ingredients, what to cook with ingredients at home, recipe finder",
  },
  blog: {
    title: "Recipe Generator Blog | Cooking Tips & SEO Strategies",
    description: "Discover cooking tips, recipe ideas, and SEO strategies to help your food website rank on Google's first page.",
    keywords: "recipe blog, food blog SEO, recipe website keywords, cooking tips, recipe ideas",
  },
  faq: {
    title: "Recipe Generator FAQ | Common Questions About Our AI Recipe Tool",
    description: "Find answers to frequently asked questions about our AI-powered recipe generator tool and how to get the most out of it.",
    keywords: "recipe generator FAQ, recipe tool questions, AI recipe generator help, recipe finder help",
  },
  about: {
    title: "About Recipe Generator | Our Story & Mission",
    description: "Learn about Recipe Generator's mission to reduce food waste and inspire culinary creativity through AI-powered recipe suggestions.",
    keywords: "about recipe generator, recipe generator mission, AI recipe tool, recipe finder story",
  },
  contact: {
    title: "Contact Recipe Generator | Get in Touch With Our Team",
    description: "Have questions or feedback about our recipe generator? Contact our team for support, partnership opportunities, or general inquiries.",
    keywords: "contact recipe generator, recipe tool support, recipe finder help, recipe generator feedback",
  },
};

export const blogPostMetadata = {
  "top-keywords-recipe-website-google-ranking": {
    title: "Top 10 Keywords to Rank Your Recipe Website on Google's First Page",
    description: "Discover the most effective keywords to help your recipe website reach the top of Google search results and attract more visitors.",
    keywords: "recipe website SEO, recipe website keywords, food blog SEO, recipe website Google ranking, recipe SEO strategy",
    author: "SEO Expert",
    publishDate: "2025-03-20",
    modifiedDate: "2025-03-20",
    category: "SEO",
  },
  "how-recipe-generators-use-ai": {
    title: "How Recipe Generators Use AI to Create Perfect Meal Combinations",
    description: "A deep dive into the technology behind AI recipe generators and how they create surprisingly delicious recipe combinations.",
    keywords: "AI recipe generator, recipe AI technology, artificial intelligence cooking, AI meal planning, recipe technology",
    author: "Tech Foodie",
    publishDate: "2025-03-08",
    modifiedDate: "2025-03-08",
    category: "Technology",
  },
  "guide-recipes-with-ingredients-you-have": {
    title: "The Ultimate Guide to Finding Recipes with Ingredients You Already Have",
    description: "Stop wondering what to cook with the ingredients in your pantry. This comprehensive guide shows you how to make delicious meals with what you have.",
    keywords: "recipes with ingredients you have, cook with available ingredients, use ingredients on hand, pantry recipes, leftover ingredient recipes",
    author: "Kitchen Hacker",
    publishDate: "2025-03-15",
    modifiedDate: "2025-03-15",
    category: "Cooking Tips",
  },
};
