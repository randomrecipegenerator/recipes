import React from 'react';
import HeroSection from '../components/HeroSection';
import RecipeGenerator from '../components/RecipeGenerator';
import SectionHeader from '../components/SectionHeader';
import FeatureCard from '../components/FeatureCard';
import CTASection from '../components/CTASection';
import FAQItem from '../components/FAQItem';

export default function Home() {
  // FAQ items with questions and answers
  const faqItems = [
    {
      question: "What is a Recipe Generator?",
      answer: "A Recipe Generator is an online tool that creates completely random, surprise recipes based on minimal inputs. Our free Recipe Generator uses AI to instantly create unexpected recipe combinations that can inspire your cooking creativity."
    },
    {
      question: "How does this Recipe Generator work?",
      answer: "Our Recipe Generator uses advanced AI to create truly random recipe combinations. You can enter minimal information or select \"Surprise Me\" for completely random suggestions. The generator will create unique recipes with accurate measurements, cooking times, and surprising ingredient combinations."
    },
    {
      question: "Is this Recipe Generator completely free?",
      answer: "Yes! Our Recipe Generator is 100% free to use with no limitations. You can generate as many random recipes as you want without any cost or subscription required."
    },
    {
      question: "Why use a Recipe Generator?",
      answer: "A Recipe Generator helps break cooking routines and inspires creativity in the kitchen. When you're bored with your usual meals or have random ingredients to use up, our Recipe Generator can suggest unexpected combinations that actually work well together."
    },
    {
      question: "Can I save my generated recipes?",
      answer: "Currently, you can copy and save the recipes manually. We're working on adding a feature to save your favorite generated recipes directly on our platform."
    },
    {
      question: "How accurate are the recipes?",
      answer: "Our AI is trained on thousands of recipes to ensure that the combinations it suggests are practical and delicious. However, as with any AI-generated content, we recommend using your cooking knowledge to adjust as needed."
    }
  ];

  return (
    <main>
      {/* Hero Section */}
      <HeroSection 
        title="AI Recipe Generator: Find Recipes With Ingredients You Have"
        subtitle="Our AI-powered recipe generator creates personalized recipes instantly from any ingredients in your kitchen"
        primaryCTA={{
          text: "Generate Recipes Now - 100% Free",
          href: "#generator"
        }}
        secondaryCTA={{
          text: "How It Works",
          href: "#how-it-works"
        }}
      />

      {/* Recipe Generator Tool Section */}
      <section id="generator" className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <SectionHeader 
            title="Free Online Recipe Generator"
            subtitle="Get completely random recipes in seconds with our AI-powered Recipe Generator tool"
          />
          
          <div className="card max-w-3xl mx-auto">
            <RecipeGenerator />
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section id="how-it-works" className="py-16">
        <div className="container mx-auto px-4">
          <SectionHeader title="How It Works" />
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="bg-[rgb(var(--primary-color))] text-white w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-4">1</div>
              <h3 className="text-xl font-semibold mb-2">Enter Ingredients</h3>
              <p className="text-gray-600">Enter ingredients you have or want to use</p>
            </div>
            <div className="text-center">
              <div className="bg-[rgb(var(--primary-color))] text-white w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-4">2</div>
              <h3 className="text-xl font-semibold mb-2">Select Preferences</h3>
              <p className="text-gray-600">Choose cuisine, meal type, and dietary restrictions</p>
            </div>
            <div className="text-center">
              <div className="bg-[rgb(var(--primary-color))] text-white w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-4">3</div>
              <h3 className="text-xl font-semibold mb-2">Get Recipes</h3>
              <p className="text-gray-600">Get instant AI-generated recipes tailored to your inputs</p>
            </div>
            <div className="text-center">
              <div className="bg-[rgb(var(--primary-color))] text-white w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-4">4</div>
              <h3 className="text-xl font-semibold mb-2">Cook & Enjoy</h3>
              <p className="text-gray-600">Follow the recipe and enjoy your personalized meal</p>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <SectionHeader title="Features" />
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <FeatureCard 
              title="AI-Powered Recipe Creation"
              description="Our advanced AI creates unique recipes that are both creative and practical"
            />
            <FeatureCard 
              title="Works With Any Ingredients"
              description="Enter whatever ingredients you have on hand and get recipes that use them"
            />
            <FeatureCard 
              title="Customizable By Cuisine"
              description="Filter recipes by cuisine type to match your taste preferences"
            />
            <FeatureCard 
              title="Dietary Restriction Options"
              description="Find recipes that match your dietary needs and preferences"
            />
            <FeatureCard 
              title="100% Free To Use"
              description="No subscription or payment required to use our recipe generator"
            />
            <FeatureCard 
              title="Unlimited Recipe Generation"
              description="Generate as many recipes as you want without any limitations"
            />
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <SectionHeader title="Recipe Generator FAQs" />
          <div className="max-w-3xl mx-auto">
            {faqItems.map((item, index) => (
              <FAQItem key={index} question={item.question} answer={item.answer} />
            ))}
          </div>
          <div className="text-center mt-8">
            <a href="/faq" className="secondary-button">View All FAQs</a>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <CTASection 
        title="Ready to Generate Your First Recipe?"
        subtitle="Try our AI-powered Recipe Generator now - it's 100% free!"
        buttonText="Generate Recipes Now"
        buttonHref="#generator"
      />
    </main>
  );
}
