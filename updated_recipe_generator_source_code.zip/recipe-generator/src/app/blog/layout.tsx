import { Metadata } from 'next';
import { siteMetadata, pageMetadata } from '../../metadata';

export const metadata: Metadata = {
  title: pageMetadata.blog.title,
  description: pageMetadata.blog.description,
  keywords: pageMetadata.blog.keywords,
  authors: [{ name: siteMetadata.author }],
  openGraph: {
    title: pageMetadata.blog.title,
    description: pageMetadata.blog.description,
    url: `${siteMetadata.siteUrl}/blog`,
    siteName: siteMetadata.title,
    locale: 'en_US',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: pageMetadata.blog.title,
    description: pageMetadata.blog.description,
    creator: siteMetadata.twitterHandle,
  },
  robots: {
    index: true,
    follow: true,
  },
  alternates: {
    canonical: `${siteMetadata.siteUrl}/blog`,
  },
};

export default function BlogLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return children;
}
