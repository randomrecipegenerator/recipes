import { Metadata } from 'next';
import { siteMetadata, blogPostMetadata } from '../../../metadata';

export const metadata: Metadata = {
  title: blogPostMetadata['top-keywords-recipe-website-google-ranking'].title,
  description: blogPostMetadata['top-keywords-recipe-website-google-ranking'].description,
  keywords: blogPostMetadata['top-keywords-recipe-website-google-ranking'].keywords,
  authors: [{ name: blogPostMetadata['top-keywords-recipe-website-google-ranking'].author }],
  openGraph: {
    title: blogPostMetadata['top-keywords-recipe-website-google-ranking'].title,
    description: blogPostMetadata['top-keywords-recipe-website-google-ranking'].description,
    url: `${siteMetadata.siteUrl}/blog/top-keywords-recipe-website-google-ranking`,
    siteName: siteMetadata.title,
    locale: 'en_US',
    type: 'article',
    publishedTime: blogPostMetadata['top-keywords-recipe-website-google-ranking'].publishDate,
    modifiedTime: blogPostMetadata['top-keywords-recipe-website-google-ranking'].modifiedDate,
    authors: [blogPostMetadata['top-keywords-recipe-website-google-ranking'].author],
  },
  twitter: {
    card: 'summary_large_image',
    title: blogPostMetadata['top-keywords-recipe-website-google-ranking'].title,
    description: blogPostMetadata['top-keywords-recipe-website-google-ranking'].description,
    creator: siteMetadata.twitterHandle,
  },
  robots: {
    index: true,
    follow: true,
  },
  alternates: {
    canonical: `${siteMetadata.siteUrl}/blog/top-keywords-recipe-website-google-ranking`,
  },
};

export default function BlogPostLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return children;
}
