import React from 'react';
import SectionHeader from '../../components/SectionHeader';
import BlogPostCard from '../../components/BlogPostCard';
import CTASection from '../../components/CTASection';

export default function Blog() {
  // Sample blog posts data
  const blogPosts = [
    {
      title: "Top 10 Keywords to Rank Your Recipe Website on Google's First Page",
      excerpt: "Discover the most effective keywords to help your recipe website reach the top of Google search results and attract more visitors.",
      date: "March 20, 2025",
      author: "SEO Expert",
      slug: "top-keywords-recipe-website-google-ranking",
      category: "SEO"
    },
    {
      title: "How to Use AI Recipe Generators to Reduce Food Waste",
      excerpt: "Learn how AI-powered recipe generators can help you use up ingredients before they expire, saving money and reducing waste.",
      date: "March 18, 2025",
      author: "Eco Chef",
      slug: "ai-recipe-generators-reduce-food-waste",
      category: "Sustainability"
    },
    {
      title: "The Ultimate Guide to Finding Recipes with Ingredients You Already Have",
      excerpt: "Stop wondering what to cook with the ingredients in your pantry. This comprehensive guide shows you how to make delicious meals with what you have.",
      date: "March 15, 2025",
      author: "Kitchen Hacker",
      slug: "guide-recipes-with-ingredients-you-have",
      category: "Cooking Tips"
    },
    {
      title: "SEO Strategies for Food Bloggers: Getting to Google's First Page",
      excerpt: "Detailed strategies and techniques specifically for food bloggers to improve their search engine rankings and reach more readers.",
      date: "March 12, 2025",
      author: "Food Blog Pro",
      slug: "seo-strategies-food-bloggers-google-first-page",
      category: "SEO"
    },
    {
      title: "What to Cook When You Have Nothing in the House",
      excerpt: "Empty fridge? Bare pantry? No problem! Discover creative recipes you can make with minimal ingredients that you probably have on hand.",
      date: "March 10, 2025",
      author: "Resourceful Cook",
      slug: "what-to-cook-nothing-in-house",
      category: "Recipe Ideas"
    },
    {
      title: "How Recipe Generators Use AI to Create Perfect Meal Combinations",
      excerpt: "A deep dive into the technology behind AI recipe generators and how they create surprisingly delicious recipe combinations.",
      date: "March 8, 2025",
      author: "Tech Foodie",
      slug: "how-recipe-generators-use-ai",
      category: "Technology"
    }
  ];

  // Blog categories
  const categories = [
    "All Categories",
    "SEO",
    "Recipe Ideas",
    "Cooking Tips",
    "Technology",
    "Sustainability"
  ];

  return (
    <main>
      {/* Hero Section */}
      <section className="bg-gray-100 py-16">
        <div className="container mx-auto px-4">
          <h1 className="text-4xl font-bold mb-4">Recipe Generator Blog</h1>
          <p className="text-xl text-gray-600 mb-8">Cooking tips, recipe ideas, and SEO strategies for food websites</p>
          <div className="flex flex-wrap gap-3">
            {categories.map((category, index) => (
              <a 
                key={index} 
                href={`#${category.toLowerCase().replace(' ', '-')}`}
                className={`px-4 py-2 rounded-full text-sm ${
                  index === 0 
                    ? 'bg-[rgb(var(--primary-color))] text-white' 
                    : 'bg-white text-gray-700 hover:bg-gray-200'
                }`}
              >
                {category}
              </a>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Post */}
      <section className="py-12">
        <div className="container mx-auto px-4">
          <SectionHeader title="Featured Post" centered={false} />
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="h-full bg-gray-200 rounded-lg">
              {/* Featured post image would go here */}
              <div className="w-full h-full min-h-[300px] flex items-center justify-center text-gray-400">
                Image Placeholder
              </div>
            </div>
            <div>
              <div className="bg-[rgb(var(--primary-color))] text-white px-3 py-1 text-sm inline-block mb-4">
                SEO
              </div>
              <h3 className="text-3xl font-bold mb-4">
                <a href="/blog/top-keywords-recipe-website-google-ranking" className="hover:text-[rgb(var(--primary-color))]">
                  Top 10 Keywords to Rank Your Recipe Website on Google's First Page
                </a>
              </h3>
              <p className="text-gray-600 mb-6">
                Discover the most effective keywords to help your recipe website reach the top of Google search results and attract more visitors. This comprehensive guide breaks down the exact terms users are searching for and how to implement them effectively on your site.
              </p>
              <div className="flex items-center text-sm text-gray-500 mb-6">
                <span className="mr-4">March 20, 2025</span>
                <span>By SEO Expert</span>
              </div>
              <a 
                href="/blog/top-keywords-recipe-website-google-ranking" 
                className="primary-button"
              >
                Read Full Article
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* Latest Posts */}
      <section className="py-12 bg-gray-50">
        <div className="container mx-auto px-4">
          <SectionHeader title="Latest Posts" centered={false} />
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {blogPosts.map((post, index) => (
              <BlogPostCard key={index} {...post} />
            ))}
          </div>
          <div className="text-center mt-12">
            <button className="secondary-button">Load More Articles</button>
          </div>
        </div>
      </section>

      {/* Newsletter Section */}
      <section className="py-16 bg-[rgb(var(--secondary-color))] text-white">
        <div className="container mx-auto px-4 text-center">
          <SectionHeader 
            title="Subscribe to Our Newsletter" 
            subtitle="Get the latest recipe ideas, cooking tips, and SEO strategies delivered straight to your inbox"
          />
          <div className="flex flex-col md:flex-row gap-4 max-w-md mx-auto">
            <input 
              type="email" 
              placeholder="Your email address" 
              className="px-4 py-3 rounded-md flex-grow text-gray-800"
            />
            <button className="bg-white text-[rgb(var(--secondary-color))] px-6 py-3 rounded-md font-semibold hover:bg-gray-100">
              Subscribe
            </button>
          </div>
        </div>
      </section>
    </main>
  );
}
