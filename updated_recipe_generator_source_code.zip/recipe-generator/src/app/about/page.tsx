import React from 'react';
import SectionHeader from '../../components/SectionHeader';
import CTASection from '../../components/CTASection';

export default function About() {
  return (
    <main>
      {/* Hero Section */}
      <section className="bg-gray-100 py-16">
        <div className="container mx-auto px-4">
          <h1 className="text-4xl font-bold mb-4">About Recipe Generator</h1>
          <p className="text-xl text-gray-600">Learn more about our AI-powered recipe generation platform</p>
        </div>
      </section>

      {/* Our Story Section */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto">
            <SectionHeader 
              title="Our Story" 
              subtitle="How Recipe Generator was born from a simple idea"
              centered={false}
            />
            <p className="mb-6 text-gray-700">
              Recipe Generator started with a simple problem: having ingredients in the kitchen but no idea what to cook with them. Our founder, a passionate home cook, was tired of searching through countless recipe websites trying to find dishes that matched the ingredients already available at home.
            </p>
            <p className="mb-6 text-gray-700">
              In 2024, we set out to create a solution that would help people discover new recipes based on what they already have, reducing food waste and making cooking more accessible and enjoyable for everyone.
            </p>
            <p className="mb-6 text-gray-700">
              By leveraging the latest advancements in artificial intelligence, we developed a powerful recipe generation algorithm that can create unique, delicious recipes from any combination of ingredients. Our AI has been trained on thousands of recipes from diverse cuisines around the world, ensuring that the suggestions are both practical and creative.
            </p>
            <p className="text-gray-700">
              Today, Recipe Generator helps thousands of home cooks break out of their cooking routines, reduce food waste, and discover new favorite dishes. And the best part? It's completely free to use, with no subscriptions or hidden fees.
            </p>
          </div>
        </div>
      </section>

      {/* Our Mission Section */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto">
            <SectionHeader 
              title="Our Mission" 
              subtitle="What drives us every day"
              centered={false}
            />
            <div className="bg-white p-6 rounded-lg shadow-sm mb-8">
              <p className="text-xl font-medium text-center italic text-gray-700">
                "To inspire culinary creativity and reduce food waste by making recipe discovery accessible to everyone."
              </p>
            </div>
            <p className="mb-6 text-gray-700">
              At Recipe Generator, we believe that cooking should be accessible, enjoyable, and sustainable. Our mission is to help people make the most of the ingredients they already have, reducing food waste while discovering delicious new recipes.
            </p>
            <p className="mb-6 text-gray-700">
              We're committed to making our platform completely free and accessible to everyone, regardless of cooking experience or background. We believe that good food brings people together, and we want to be a part of that connection.
            </p>
            <p className="text-gray-700">
              As we grow, we remain dedicated to improving our AI technology, expanding our recipe database, and adding new features that make cooking more enjoyable and sustainable for our users.
            </p>
          </div>
        </div>
      </section>

      {/* Our Team Section */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <SectionHeader title="Meet Our Team" />
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            <div className="text-center">
              <div className="w-40 h-40 bg-gray-200 rounded-full mx-auto mb-4">
                {/* Team member image would go here */}
              </div>
              <h3 className="text-xl font-semibold">Alex Johnson</h3>
              <p className="text-gray-600">Founder & CEO</p>
            </div>
            <div className="text-center">
              <div className="w-40 h-40 bg-gray-200 rounded-full mx-auto mb-4">
                {/* Team member image would go here */}
              </div>
              <h3 className="text-xl font-semibold">Maria Rodriguez</h3>
              <p className="text-gray-600">AI Engineer</p>
            </div>
            <div className="text-center">
              <div className="w-40 h-40 bg-gray-200 rounded-full mx-auto mb-4">
                {/* Team member image would go here */}
              </div>
              <h3 className="text-xl font-semibold">David Chen</h3>
              <p className="text-gray-600">Head of Content</p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <CTASection 
        title="Ready to Try Our Recipe Generator?"
        subtitle="Generate personalized recipes based on ingredients you have at home"
        buttonText="Try It Now - 100% Free"
        buttonHref="/#generator"
      />
    </main>
  );
}
